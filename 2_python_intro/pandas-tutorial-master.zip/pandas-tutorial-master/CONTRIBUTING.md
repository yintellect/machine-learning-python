# Pandas Tutorial - contributing guide

This tutorial can be freely used, and I also welcome contributions.

Some notes (for the future me as well :-)):

- edit the 'solved' notebooks, the other ones (the ones used in the tutorial) are generated automatically using the `convert_notebooks.sh` script.
- the exercises are cleared using the `nbtutor` notebook extension: https://github.com/jorisvandenbossche/nbtutor




