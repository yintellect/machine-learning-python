c.Exporter.preprocessors = ['nbtutor.ClearExercisePreprocessor', 'nbconvert.preprocessors.ClearOutputPreprocessor']
