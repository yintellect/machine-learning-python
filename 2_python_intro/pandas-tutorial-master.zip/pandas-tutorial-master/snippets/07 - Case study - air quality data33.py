data_files = glob.glob("data/*0008001*")
data_files