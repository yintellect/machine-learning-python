d = sel['Superman'] - sel['Batman']
print('Superman years:')
print(len(d[d > 0.0]))