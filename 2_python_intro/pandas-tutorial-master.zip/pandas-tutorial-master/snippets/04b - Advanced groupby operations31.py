title_longest = titles['title'].str.len().nlargest(10)
title_longest