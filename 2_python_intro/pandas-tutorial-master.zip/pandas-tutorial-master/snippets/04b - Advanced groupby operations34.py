t = titles
t.year.value_counts().head(3)