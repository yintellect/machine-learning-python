temp.columns.name = 'Pclass'
temp = temp.stack()
temp