# We reset the index to have the date and hours available as columns
data_stacked = data_stacked.reset_index()
data_stacked.head()