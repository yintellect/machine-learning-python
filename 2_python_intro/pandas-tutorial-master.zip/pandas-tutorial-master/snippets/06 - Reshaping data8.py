data = data.drop('flag', axis=1)
data