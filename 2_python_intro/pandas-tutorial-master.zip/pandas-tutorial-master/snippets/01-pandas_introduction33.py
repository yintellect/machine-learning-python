# df['Survived'].sum() / len(df['Survived'])
df['Survived'].mean()