data['months'] = data.index.month
data[data['months'].isin([1, 2, 3])]