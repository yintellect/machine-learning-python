yearly.plot()
plt.axhline(40, linestyle='--', color='k')