ratios_decade[:, 'actor'].plot()
ratios_decade[:, 'actress'].plot()