fig, ax = plt.subplots()
data['2013'].mean().plot(kind='barh', ax=ax)