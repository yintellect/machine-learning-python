pd.options.display.max_colwidth = 210
titles.loc[title_longest.index]