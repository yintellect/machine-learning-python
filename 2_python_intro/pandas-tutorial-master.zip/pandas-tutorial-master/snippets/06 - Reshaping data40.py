temp = pivoted.set_index('Sex')
temp